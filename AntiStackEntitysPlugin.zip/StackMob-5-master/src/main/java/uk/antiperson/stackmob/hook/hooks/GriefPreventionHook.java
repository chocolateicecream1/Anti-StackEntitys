package uk.antiperson.stackmob.hook.hooks;

public class GriefPreventionHook {
}
