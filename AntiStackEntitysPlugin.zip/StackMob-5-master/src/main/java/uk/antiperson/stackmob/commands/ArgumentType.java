package uk.antiperson.stackmob.commands;

public enum ArgumentType {
    BOOLEAN,
    STRING,
    INTEGER,
    ENTITY_TYPE,
    WORLD
}
