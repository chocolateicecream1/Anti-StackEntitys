package uk.antiperson.stackmob.hook;

public interface PreventStackHook extends CustomMobHook {
}
