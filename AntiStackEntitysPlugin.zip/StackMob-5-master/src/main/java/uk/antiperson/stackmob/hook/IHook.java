package uk.antiperson.stackmob.hook;

public interface IHook {
    void onEnable();
    void onLoad();
}
